# ISFD Virasoro - Sistema QR Emergencias

## Pasos para publicar en GitHub Pages

### 1. Crear cuenta en GitHub
- Ir a github.com
- Registrarse con el Gmail del equipo
- Elegir un nombre de usuario simple, ej: `isfd-virasoro`

### 2. Crear el repositorio
- Click en "New repository"
- Nombre: `isfd-qr`
- Marcar "Public"
- Click "Create repository"

### 3. Subir los archivos
- Click en "uploading an existing file"
- Arrastrar TODOS los archivos HTML de esta carpeta
- Click "Commit changes"

### 4. Activar GitHub Pages
- Ir a Settings del repositorio
- Seccion "Pages"
- Source: "Deploy from a branch"
- Branch: "main" / carpeta "root"
- Click "Save"

### 5. Tu URL sera:
https://isfd-virasoro.github.io/isfd-qr/

### 6. Generar los QR
Usar qr-code-generator.com con estas URLs:

- Aula 18 THYS: https://isfd-virasoro.github.io/isfd-qr/aula-18.html
- Aula 19 PESF: https://isfd-virasoro.github.io/isfd-qr/aula-19.html
- Aula 20 CLI:  https://isfd-virasoro.github.io/isfd-qr/aula-20.html
- Aula 21 THYS: https://isfd-virasoro.github.io/isfd-qr/aula-21.html
- Aula 22 THYS: https://isfd-virasoro.github.io/isfd-qr/aula-22.html
- Laboratorio:  https://isfd-virasoro.github.io/isfd-qr/laboratorio.html
- Biblioteca:   https://isfd-virasoro.github.io/isfd-qr/biblioteca.html
- Informatica 1: https://isfd-virasoro.github.io/isfd-qr/informatica-1.html
- Informatica 2: https://isfd-virasoro.github.io/isfd-qr/informatica-2.html
- Informatica 3: https://isfd-virasoro.github.io/isfd-qr/informatica-3.html
- Inicial 2do:  https://isfd-virasoro.github.io/isfd-qr/inicial-2.html
- Inicial 3ro:  https://isfd-virasoro.github.io/isfd-qr/inicial-3.html
- Inicial 4to:  https://isfd-virasoro.github.io/isfd-qr/inicial-4.html
- Ingles/CLI:   https://isfd-virasoro.github.io/isfd-qr/ingles.html
- Hoteleria:    https://isfd-virasoro.github.io/isfd-qr/hoteleria.html
- Sala Plastica: https://isfd-virasoro.github.io/isfd-qr/sala-plastica.html

### 7. Imprimir y pegar
- Imprimir cada QR en etiqueta adhesiva o papel plastificado
- Pegar en la puerta de cada aula (altura: 150 cm desde el piso)
- Tambien pegar uno en la pared de la Zona Ciega del aula

---
Escuelas Resilientes - Seguridad 4.0 - ISFD Gobernador Virasoro 2026
